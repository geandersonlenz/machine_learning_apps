# Matcher

Python library for performing propensity score matching via logistic regression
