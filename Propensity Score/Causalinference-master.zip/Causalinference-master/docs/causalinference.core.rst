causalinference.core package
============================

causalinference.core.data module
--------------------------------

.. automodule:: causalinference.core.data
    :members:
    :show-inheritance:

causalinference.core.propensity module
--------------------------------------

.. automodule:: causalinference.core.propensity
    :members:
    :show-inheritance:

causalinference.core.strata module
----------------------------------

.. automodule:: causalinference.core.strata
    :members:
    :show-inheritance:

causalinference.core.summary module
-----------------------------------

.. automodule:: causalinference.core.summary
    :members:
    :show-inheritance:

