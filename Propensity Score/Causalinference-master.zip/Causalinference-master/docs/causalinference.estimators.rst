causalinference.estimators package
==================================

causalinference.estimators.base module
--------------------------------------

.. automodule:: causalinference.estimators.base
    :members:
    :show-inheritance:

causalinference.estimators.blocking module
------------------------------------------

.. automodule:: causalinference.estimators.blocking
    :members:
    :show-inheritance:

causalinference.estimators.matching module
------------------------------------------

.. automodule:: causalinference.estimators.matching
    :members:
    :show-inheritance:

causalinference.estimators.ols module
-------------------------------------

.. automodule:: causalinference.estimators.ols
    :members:
    :show-inheritance:

causalinference.estimators.weighting module
-------------------------------------------

.. automodule:: causalinference.estimators.weighting
    :members:
    :show-inheritance:

