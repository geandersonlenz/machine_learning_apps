[![Build Status](https://travis-ci.org/kellieotto/pscore_match.svg?branch=master)](https://travis-ci.org/kellieotto/pscore_match)
[![Coverage Status](https://coveralls.io/repos/github/kellieotto/pscore_match/badge.svg?branch=master)](https://coveralls.io/github/kellieotto/pscore_match?branch=master)

# pscore_match
A Python package for propensity score matching 
