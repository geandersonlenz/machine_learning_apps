`match` module
--------------

.. automodule:: pscore_match.match
    :members:
	