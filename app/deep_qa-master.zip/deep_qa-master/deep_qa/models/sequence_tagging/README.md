Sequence tagging models take a sequence of text as input and produce as output a label for each
token in the sequence.  These models could do named entity recognition with BIO tags, or part of
speech tagging, or other similar tasks.
