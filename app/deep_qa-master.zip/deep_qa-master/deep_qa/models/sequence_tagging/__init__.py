from .simple_tagger import SimpleTagger

concrete_models = {  # pylint: disable=invalid-name
        'SimpleTagger': SimpleTagger,
        }
