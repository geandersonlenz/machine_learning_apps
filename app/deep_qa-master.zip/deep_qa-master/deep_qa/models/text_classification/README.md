Text classification models take a sequence of text as input and classify it into one of several
classes.

*Input:* Text sequence

*Output:* Class label
