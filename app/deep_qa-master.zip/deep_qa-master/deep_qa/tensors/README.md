This module contains convenience functions for working with Keras tensors.  Typically these
functions will be called inside some `Layer` class.
