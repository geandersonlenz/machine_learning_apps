from .instance import Instance, TextInstance, IndexedInstance
