Layers in this module compute some kind of "attention" over a vector or matrix.  "Attention"
typically means a normalized probability distribution, and is typically computed using a softmax
after some similarity computation, so we're also grouping layers that do some kind of specialized
softmax in this module.
