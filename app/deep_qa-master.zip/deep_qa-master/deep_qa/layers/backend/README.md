Layers in this module generally just implement some simple operation from the Keras backend as a
Layer.  The reason we have these as Layers is largely so that we can properly handle masking.
