Common Utils
============

Here are some general utilities that we've written to help in other parts of the
code base.
