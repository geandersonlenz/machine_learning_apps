Datasets
========


deep_qa.data.dataset
--------------------

.. automodule:: deep_qa.data.datasets.dataset
    :members:
    :undoc-members:
    :show-inheritance:

Entailment
----------

.. automodule:: deep_qa.data.datasets.entailment.snli_dataset
    :members:
    :undoc-members:
    :show-inheritance:

Language Modeling
-----------------

.. automodule:: deep_qa.data.datasets.language_modeling.language_modeling_dataset
    :members:
    :undoc-members:
    :show-inheritance: