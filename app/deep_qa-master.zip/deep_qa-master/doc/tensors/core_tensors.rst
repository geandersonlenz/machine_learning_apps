Core Tensor Utils
=================

backend
-------

.. automodule:: deep_qa.tensors.backend
    :members:
    :undoc-members:
    :show-inheritance:

masked_operations
-----------------

.. automodule:: deep_qa.tensors.masked_operations
    :members:
    :undoc-members:
    :show-inheritance:
