Tensor Utils
============

Here are some general tensor manipulation utilities that we've written to help
in other parts of the code base.
