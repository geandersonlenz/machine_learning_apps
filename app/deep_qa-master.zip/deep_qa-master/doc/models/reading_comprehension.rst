Reading Comprehension
=====================

AttentionSumReader
------------------

.. automodule:: deep_qa.models.reading_comprehension.attention_sum_reader
    :members:
    :undoc-members:
    :show-inheritance:

BidirectionalAttentionFlow
--------------------------

.. automodule:: deep_qa.models.reading_comprehension.bidirectional_attention
    :members:
    :undoc-members:
    :show-inheritance:

GatedAttentionReader
--------------------

.. automodule:: deep_qa.models.reading_comprehension.gated_attention_reader
    :members:
    :undoc-members:
    :show-inheritance:
