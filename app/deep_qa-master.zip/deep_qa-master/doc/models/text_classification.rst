Text Classification
===================

Text classification models take a sequence of text as input and classify it into
one of several classes.

Input: Text sequence

Output: Class label


ClassificationModel
-------------------

.. automodule:: deep_qa.models.text_classification.classification_model
    :members:
    :undoc-members:
    :show-inheritance:
