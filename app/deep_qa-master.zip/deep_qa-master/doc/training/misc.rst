Misc
====

Models
------

.. automodule:: deep_qa.training.models
    :members:
    :undoc-members:
    :show-inheritance:

Optimizers
----------

.. automodule:: deep_qa.training.optimizers
    :members:
    :undoc-members:
    :show-inheritance:
